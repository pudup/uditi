def scan_disk_scheduling(requests, head_position, direction, disk_size):
    total_movement = 0
    current_position = head_position
    requests = sorted(requests)

    if direction == "left":
        # Process requests to the left of the head
        left = [req for req in requests if req <= head_position]
        right = [req for req in requests if req > head_position]

        for req in reversed(left):
            total_movement += abs(req - current_position)
            current_position = req

        # Move to the start of the disk if needed
        if left:
            total_movement += current_position  # Move to 0
            current_position = 0

        # Process requests to the right
        for req in right:
            total_movement += abs(req - current_position)
            current_position = req

    elif direction == "right":
        # Process requests to the right of the head
        left = [req for req in requests if req < head_position]
        right = [req for req in requests if req >= head_position]

        for req in right:
            total_movement += abs(req - current_position)
            current_position = req

        # Move to the end of the disk if needed
        if right:
            total_movement += abs(disk_size - 1 - current_position)  # Move to disk_size - 1
            current_position = disk_size - 1

        # Process requests to the left
        for req in reversed(left):
            total_movement += abs(req - current_position)
            current_position = req

    print("Total Head Movement:", total_movement)

# Example Input
requests = [98, 183, 37, 122, 14, 124, 65, 67]
head_position = 53
direction = "left"  # Can be "left" or "right"
disk_size = 200

