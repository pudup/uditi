def priority_scheduling_non_preemptive(processes, arrival_times, burst_times, priorities):
    n = len(processes)
    completed = 0
    current_time = 0
    is_completed = [False] * n
    waiting_times = [0] * n
    turnaround_times = [0] * n
    gantt_chart = []

    while completed < n:
        # Find the highest priority process that has arrived and is not completed
        highest_priority = float('inf')
        selected_process = None

        for i in range(n):
            if arrival_times[i] <= current_time and not is_completed[i] and priorities[i] < highest_priority:
                highest_priority = priorities[i]
                selected_process = i

        if selected_process is None:  # No process available, increment time
            current_time += 1
            continue

        # Execute the selected process
        gantt_chart.append((current_time, processes[selected_process]))
        current_time += burst_times[selected_process]
        is_completed[selected_process] = True
        completed += 1

        # Calculate turnaround and waiting times
        turnaround_times[selected_process] = current_time - arrival_times[selected_process]
        waiting_times[selected_process] = turnaround_times[selected_process] - burst_times[selected_process]

    # Print Gantt chart
    print("\nGantt Chart:")
    for i in range(len(gantt_chart)):
        print(f"| P{gantt_chart[i][1]} ", end="")
    print("|")
    print("0", end="")
    for time, _ in gantt_chart:
        print(f"  {time} ", end="")
    print(current_time)

    # Print results
    print("\nProcess\tArrival Time\tBurst Time\tPriority\tWaiting Time\tTurnaround Time")
    for i in range(n):
        print(f"P{processes[i]}\t\t{arrival_times[i]}\t\t{burst_times[i]}\t\t{priorities[i]}\t\t{waiting_times[i]}\t\t{turnaround_times[i]}")

    print("\nAverage Waiting Time:", sum(waiting_times) / n)
    print("Average Turnaround Time:", sum(turnaround_times) / n)

# Example Input
processes = [1, 2, 3]
arrival_times = [0, 1, 2]
burst_times = [5, 3, 8]
priorities = [2, 1, 3]

priority_scheduling_non_preemptive(processes, arrival_times, burst_times, priorities)

