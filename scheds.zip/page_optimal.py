def optimal_page_replacement(pages, capacity):
    memory = []
    page_faults = 0

    for i in range(len(pages)):
        if pages[i] not in memory:
            if len(memory) < capacity:
                memory.append(pages[i])
            else:
                # Find the page to replace
                farthest_index = -1
                farthest_page = None
                for page in memory:
                    curr_position = i + 1
                    if page in pages[curr_position:]:
                        curr_index = pages[curr_position:].index(page) + curr_position
                    else:
                        curr_index = float('inf')  # Not used again
                    if curr_index > farthest_index:
                        farthest_index = curr_index
                        farthest_page = page
                memory.remove(farthest_page)
                memory.append(pages[i])
            page_faults += 1
        print(f"Memory: {memory}")

    return page_faults


pages = [7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2]
capacity = 3

faults = optimal_page_replacement(pages, capacity)
print(f"Total Page Faults: {faults}")
