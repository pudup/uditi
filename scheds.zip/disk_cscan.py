def cscan(arr, head, direction):
    seek_count = 0
    left = []
    right = []

    for i in arr:
        if i < head:
            left.append(i)
        if i > head:
            right.append(i)

    left.sort()
    right.sort()

    if direction == "left":
        # Seek to the left end and then move to the right end
        for i in range(len(left) - 1, -1, -1):
            seek_count += abs(head - left[i])
            head = left[i]
        # After reaching the left end, seek to the right end
        seek_count += abs(head - 0)
        head = 0
        for i in range(len(right)):
            seek_count += abs(head - right[i])
            head = right[i]

    elif direction == "right":
        # Seek to the right end and then move to the left end
        for i in range(len(right)):
            seek_count += abs(head - right[i])
            head = right[i]
        # After reaching the right end, seek to the left end
        seek_count += abs(head - 0)
        head = 0
        for i in range(len(left) - 1, -1, -1):
            seek_count += abs(head - left[i])
            head = left[i]

    return seek_count


# Example usage
arr = [95, 180, 34, 119, 11, 123, 62, 64]
head = 50
direction = "left"
seek_count = cscan(arr, head, direction)
print(f"Total Seek Count: {seek_count}")
