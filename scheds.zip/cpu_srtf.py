def srtf_scheduling(processes, arrival_times, burst_times):
    n = len(processes)
    remaining_times = burst_times[:]
    complete = 0
    current_time = 0
    waiting_times = [0] * n
    turnaround_times = [0] * n
    gantt_chart = []

    while complete < n:
        # Find the process with the shortest remaining time at the current time
        min_time = float('inf')
        shortest = None
        for i in range(n):
            if arrival_times[i] <= current_time and remaining_times[i] > 0 and remaining_times[i] < min_time:
                min_time = remaining_times[i]
                shortest = i

        if shortest is None:  # No process available at this time
            current_time += 1
            continue

        gantt_chart.append((current_time, processes[shortest]))

        # Execute the shortest job for 1 unit of time
        remaining_times[shortest] -= 1
        current_time += 1

        if remaining_times[shortest] == 0:
            complete += 1
            turnaround_times[shortest] = current_time - arrival_times[shortest]
            waiting_times[shortest] = turnaround_times[shortest] - burst_times[shortest]

    # Print Gantt chart
    print("\nGantt Chart:")
    for i in range(len(gantt_chart)):
        print(f"| P{gantt_chart[i][1]} ", end="")
    print("|")
    for time, _ in gantt_chart:
        print(f"  {time} ", end="")
    print(current_time)

    # Print results
    print("\nProcess\tArrival Time\tBurst Time\tWaiting Time\tTurnaround Time")
    for i in range(n):
        print(f"P{processes[i]}\t\t{arrival_times[i]}\t\t{burst_times[i]}\t\t{waiting_times[i]}\t\t{turnaround_times[i]}")

    print("\nAverage Waiting Time:", sum(waiting_times) / n)
    print("Average Turnaround Time:", sum(turnaround_times) / n)

# Example Input
processes = [1, 2, 3]
arrival_times = [0, 2, 4]
burst_times = [7, 4, 1]

srtf_scheduling(processes, arrival_times, burst_times)

