def fcfs_disk_scheduling(requests, head_position):
    total_movement = 0
    current_position = head_position

    for request in requests:
        total_movement += abs(request - current_position)
        current_position = request

    print("Total Head Movement:", total_movement)

# Example Input
requests = [98, 183, 37, 122, 14, 124, 65, 67]
head_position = 53

fcfs_disk_scheduling(requests, head_position)

