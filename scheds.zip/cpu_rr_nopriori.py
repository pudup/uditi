def round_robin(processes, arrival_times, burst_times, time_quantum):
    n = len(processes)
    remaining_times = burst_times[:]
    current_time = 0
    waiting_times = [0] * n
    turnaround_times = [0] * n
    gantt_chart = []
    queue = []

    # Enqueue initial processes
    for i in range(n):
        if arrival_times[i] == 0:
            queue.append(i)

    while queue or any(rt > 0 for rt in remaining_times):
        if not queue:  # If the queue is empty, move to the next available process
            current_time += 1
            for i in range(n):
                if arrival_times[i] <= current_time and remaining_times[i] > 0:
                    queue.append(i)
            continue

        # Dequeue the next process
        idx = queue.pop(0)

        gantt_chart.append((current_time, processes[idx]))

        # Execute process for the time quantum or remaining time
        executed_time = min(time_quantum, remaining_times[idx])
        remaining_times[idx] -= executed_time
        current_time += executed_time

        # Enqueue any newly arrived processes during execution
        for i in range(n):
            if arrival_times[i] <= current_time and remaining_times[i] > 0 and i not in queue:
                queue.append(i)

        # Re-enqueue the current process if it's not finished
        if remaining_times[idx] > 0:
            queue.append(idx)

        # Calculate waiting and turnaround times for completed processes
        if remaining_times[idx] == 0:
            turnaround_times[idx] = current_time - arrival_times[idx]
            waiting_times[idx] = turnaround_times[idx] - burst_times[idx]

    # Print Gantt chart
    print("\nGantt Chart:")
    for i in range(len(gantt_chart)):
        print(f"| P{gantt_chart[i][1]} ", end="")
    print("|")
    print("0", end="")
    for time, _ in gantt_chart:
        print(f"  {time} ", end="")
    print(current_time)

    # Print results
    print("\nProcess\tArrival Time\tBurst Time\tWaiting Time\tTurnaround Time")
    for i in range(n):
        print(f"P{processes[i]}\t\t{arrival_times[i]}\t\t{burst_times[i]}\t\t{waiting_times[i]}\t\t{turnaround_times[i]}")

    print("\nAverage Waiting Time:", sum(waiting_times) / n)
    print("Average Turnaround Time:", sum(turnaround_times) / n)

# Example Input
processes = [1, 2, 3]
arrival_times = [0, 1, 2]
burst_times = [5, 4, 3]
time_quantum = 2

round_robin(processes, arrival_times, burst_times, time_quantum)

