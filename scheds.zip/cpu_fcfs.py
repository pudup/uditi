def fcfs_scheduling(processes, burst_times, arrival_times):
    n = len(processes)
    waiting_times = [0] * n
    turnaround_times = [0] * n
    completion_times = [0] * n

    # Calculate completion times
    completion_times[0] = burst_times[0]
    for i in range(1, n):
        completion_times[i] = completion_times[i - 1] + burst_times[i]

    # Calculate turnaround times and waiting times
    for i in range(n):
        turnaround_times[i] = completion_times[i] - arrival_times[i]
        waiting_times[i] = turnaround_times[i] - burst_times[i]

    # Print Gantt chart
    print("\nGantt Chart:")
    for i in range(n):
        print(f"| P{processes[i]} ", end="")
    print("|")
    print("0", end="")
    for time in completion_times:
        print(f"  {time} ", end="")
    print()

    # Print results
    print("\nProcess\tBurst Time\tWaiting Time\tTurnaround Time")
    for i in range(n):
        print(f"P{processes[i]}\t\t{burst_times[i]}\t\t{waiting_times[i]}\t\t{turnaround_times[i]}")

    print("\nAverage Waiting Time:", sum(waiting_times) / n)
    print("Average Turnaround Time:", sum(turnaround_times) / n)

# Example Input
processes = [1, 2, 3]
burst_times = [5, 8, 12]
arrival_times = [0, 1 ,2]

fcfs_scheduling(processes, burst_times, arrival_times)
